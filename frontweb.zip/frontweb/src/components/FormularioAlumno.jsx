import {useState} from 'react'
//import prototype from 'prop-types'
import "../components/Formulario.css" 


const FormularioAlumno = () => {
    const [nombre, setNombre] = useState("");
    const [email, setEmail] = useState("");
    const [curso, setCurso] = useState("");
    const [sexo, setSexo] = useState("");
    const [hablaIngles, setHablaIngles] = useState(false);
    const [alumnos, setAlumnos] = useState([]);
    const [editandoId, setEditandoId] = useState(null);
    const [modoEdicion, setModoEdicion] = useState(false);

    const handleChangeSexo = (e) => {
    setSexo(e.target.value);
};

const handleSubmit = (e) => {
    e.preventDefault();
    
    if (modoEdicion && editandoId) {
        // Actualizar alumno existente
        const alumnoActualizado = {
            id: editandoId,
            Ine_alumno: Ine, 
            nombre_alumno: nombre, 
            curso_alumno: curso,
            sexo_alumno: sexo, 
            habla_ingles: hablaIngles,
        };
        
        setAlumnos(alumnos.map(alumno => 
            alumno.id === editandoId ? alumnoActualizado : alumno
        ));
        
        // Salir del modo edición
        setModoEdicion(false);
        setEditandoId(null);
    } else {
        // Crear nuevo alumno
        const nuevoAlumno = {
            id: Date.now(), // ID único basado en timestamp
            nombre_alumno: nombre, 
            email_alumno: email, 
            curso_alumno: curso,
            sexo_alumno: sexo, 
            habla_ingles: hablaIngles,
        };
        
        setAlumnos([...alumnos, nuevoAlumno]);
    }

    // Limpiar formulario
    limpiarFormulario();
};

const limpiarFormulario = () => {
    setNombre("");
    setEmail("");
    setCurso("");
    setSexo("");
    setHablaIngles(false);
    setModoEdicion(false);
    setEditandoId(null);
};

const editarAlumno = (alumno) => {
    setNombre(alumno.nombre_alumno);
    setEmail(alumno.email_alumno);
    setCurso(alumno.curso_alumno);
    setSexo(alumno.sexo_alumno);
    setHablaIngles(alumno.habla_ingles);
    setModoEdicion(true);
    setEditandoId(alumno.id);
};

const cancelarEdicion = () => {
    limpiarFormulario();
};

const eliminarAlumno = (id) => {
    setAlumnos(alumnos.filter(alumno => alumno.id !== id));
    // Si estamos editando el alumno que se elimina, cancelar edición
    if (editandoId === id) {
        cancelarEdicion();
    }
};
return (
        <div className="container-layout">
            {/* Panel izquierdo - Registros */}
            <div className="left-panel">
                <div className="records-section">
                    <h2>Registros de Alumnos</h2>
                    {alumnos.length === 0 ? (
                        <div className="no-records">
                            No hay alumnos registrados aún
                        </div>
                    ) : (
                        <table className="records-table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Email</th>
                                    <th>Curso</th>
                                    <th>Sexo</th>
                                    <th>Inglés</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {alumnos.map((alumno) => (
                                    <tr key={alumno.id} className={editandoId === alumno.id ? "editing-row" : ""}>
                                        <td>{alumno.nombre_alumno}</td>
                                        <td>{alumno.email_alumno}</td>
                                        <td>{alumno.curso_alumno}</td>
                                        <td>{alumno.sexo_alumno}</td>
                                        <td>{alumno.habla_ingles ? "Sí" : "No"}</td>
                                        <td className="actions-cell">
                                            <button 
                                                className="btn btn-edit"
                                                onClick={() => editarAlumno(alumno)}
                                                title="Editar alumno"
                                                disabled={modoEdicion && editandoId !== alumno.id}
                                            >
                                                ✏️
                                            </button>
                                            <button 
                                                className="btn btn-delete"
                                                onClick={() => eliminarAlumno(alumno.id)}
                                                title="Eliminar alumno"
                                            >
                                                🗑️
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>

            {/* Panel derecho - Formulario */}
            <div className="right-panel">
                <div className="form-section">
                    <h2>{modoEdicion ? "Editar Alumno" : "Registrar Nuevo Alumno"}</h2>
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label className="form-label">Nombre del alumno:</label>
                            <input
                                type="text"
                                name="nombre_alumno"
                                className="form-control"
                                value={nombre}
                                onChange={(e) => setNombre(e.target.value)}
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label className="form-label">Email del alumno:</label>
                            <input
                                type="email"
                                name="email_alumno"
                                className="form-control"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label className="form-label">Seleccione el curso:</label>
                            <select
                                name="curso_alumno"
                                className="form-select"
                                value={curso}
                                onChange={(e) => setCurso(e.target.value)}
                                required
                            >
                                <option value="">-- Seleccione un curso --</option>
                                <option value="ReactJS">ReactJS</option>
                                <option value="Python">Python</option>
                                <option value="NodeJS">NodeJS</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label className="form-label">Sexo del alumno:</label>
                            <div className="radio-group">
                                <div className="radio-item">
                                    <input
                                        type="radio"
                                        name="sexo_alumno"
                                        id="masculino"
                                        value="Masculino"
                                        checked={sexo === "Masculino"}
                                        onChange={handleChangeSexo}
                                    />
                                    <label htmlFor="masculino">Masculino</label>
                                </div>
                                <div className="radio-item">
                                    <input
                                        type="radio"
                                        name="sexo_alumno"
                                        id="femenino"
                                        value="Femenino"
                                        checked={sexo === "Femenino"}
                                        onChange={handleChangeSexo}
                                    />
                                    <label htmlFor="femenino">Femenino</label>
                                </div>
                            </div>
                        </div>

                        <div className="form-group">
                            <label className="form-label">¿Hablas inglés?</label>
                            <div className="checkbox-group">
                                <div className="checkbox-item">
                                    <input
                                        name="habla_ingles"
                                        type="checkbox"
                                        id="ingles"
                                        checked={hablaIngles}
                                        onChange={(e) => setHablaIngles(e.target.checked)}
                                    />
                                    <label htmlFor="ingles">
                                        {hablaIngles ? "Sí" : "No"}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div className="form-buttons">
                            <button type="submit" className="btn submit-button">
                                {modoEdicion ? "Actualizar Alumno" : "Agregar Alumno"}
                            </button>
                            {modoEdicion && (
                                <button 
                                    type="button" 
                                    className="btn btn-cancel" 
                                    onClick={cancelarEdicion}
                                >
                                    Cancelar
                                </button>
                            )}
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
/*FormularioAlumno.prototype = {
    agregarAlumno: prototype.func.isRequired,
};
export default FormularioAlumno; */
export default FormularioAlumno;
